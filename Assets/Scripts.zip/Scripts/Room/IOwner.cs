﻿public interface IOwner
{
    public void InformEnemyDeath();
}