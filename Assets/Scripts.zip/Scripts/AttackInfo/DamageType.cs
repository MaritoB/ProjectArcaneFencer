﻿ 
public enum DamageType
{
    PHYSICAL,
    COLD,
    FIRE,
    LIGHTNING,
    MAGIC 
} 