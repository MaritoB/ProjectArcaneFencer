
using UnityEngine;

public interface IProjectileOnHitEffect 
{
    void OnHitEffect(Collider collider);
}
