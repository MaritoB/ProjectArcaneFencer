public interface IProjectileMovement 
{
    void ChangeMovement();
}
