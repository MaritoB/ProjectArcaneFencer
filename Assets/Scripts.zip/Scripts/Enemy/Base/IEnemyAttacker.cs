﻿internal interface IEnemyAttacker
{
    void Attack();
}