﻿public class CriticalHitPopupText : PopupText { }
