﻿public class MagicDamagePopupText : PopupText { }
